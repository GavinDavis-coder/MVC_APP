﻿using Microsoft.AspNetCore.Mvc;
using MvcCrudApp.Models;
using MvcCrudApp.Services;
using System;
using System.Linq;

namespace MvcCrudApp.Controllers
{
    [Route("projects")]
    public class ProjectController : Controller
    {
        private readonly IProjectService _projectService;
        // Get submitter details
        private readonly IUserService _userService;

        public ProjectController(IProjectService projectService, IUserService userService)
        {
            _projectService = projectService;
            _userService = userService;
        }

        // GET: /projects
        [HttpGet("")]
        public IActionResult Index(string searchString, string status, DateTime? deadline, string technology, string tags)
        {
            // Retrieve project list for filters.
            var allProjects = _projectService.GetAll();

            // Compute distinct Technology values.
            var technologyList = allProjects
                .Where(p => !string.IsNullOrWhiteSpace(p.Technology))
                .Select(p => p.Technology)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            // Compute distinct Tag values.
            var tagsList = allProjects
                .Where(p => !string.IsNullOrWhiteSpace(p.Tags))
                .SelectMany(p => p.Tags.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                .Select(tag => tag.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            // Pass the lists to the view.
            ViewBag.TechnologyList = technologyList;
            ViewBag.TagsList = tagsList;

            // Start filtering from the full list.
            var projects = allProjects;

            if (!string.IsNullOrEmpty(searchString))
            {
                projects = projects.Where(p => p.Title.Contains(searchString, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            if (!string.IsNullOrEmpty(status))
            {
                projects = projects.Where(p => p.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            if (deadline.HasValue)
            {
                projects = projects.Where(p => p.Deadline.Date == deadline.Value.Date).ToList();
            }
            if (!string.IsNullOrEmpty(technology))
            {
                projects = projects.Where(p => p.Technology.IndexOf(technology, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
            }
            if (!string.IsNullOrEmpty(tags))
            {
                projects = projects.Where(p => p.Tags != null && p.Tags.IndexOf(tags, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
            }

            // Preserve current filter values in the ViewBag.
            ViewBag.SearchString = searchString;
            ViewBag.Status = status;
            ViewBag.Deadline = deadline?.ToString("yyyy-MM-dd");
            ViewBag.Technology = technology;
            ViewBag.Tags = tags;

            return View(projects);
        }

        // GET: /projects/create
        [HttpGet("create")]
        public IActionResult Create()
        {
            // Passing user list to select submitter
            ViewBag.Users = _userService.GetAll();
            return View(new Project());
        }

        // POST: /projects/create
        [HttpPost("create")]
        public IActionResult Create(Project project)
        {
            if (ModelState.IsValid)
            {
                _projectService.Add(project);
                return RedirectToAction("Index");
            }
            ViewBag.Users = _userService.GetAll();
            return View(project);
        }

        // GET: /projects/edit/{id}
        [HttpGet("edit/{id}")]
        public IActionResult Edit(int id)
        {
            var project = _projectService.GetById(id);
            if (project == null)
                return NotFound();

            ViewBag.Users = _userService.GetAll();
            return View(project);
        }

        // POST: /projects/edit/{id}
        [HttpPost("edit/{id}")]
        public IActionResult Edit(Project project)
        {
            if (ModelState.IsValid)
            {
                _projectService.Update(project);
                return RedirectToAction("Index");
            }
            ViewBag.Users = _userService.GetAll();
            return View(project);
        }

        // GET: /projects/delete/{id}
        [HttpGet("delete/{id}")]
        public IActionResult Delete(int id)
        {
            var project = _projectService.GetById(id);
            if (project == null)
                return NotFound();
            return View(project);
        }

        // POST: /projects/delete/{id}
        [HttpPost("delete/{id}"), ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _projectService.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
