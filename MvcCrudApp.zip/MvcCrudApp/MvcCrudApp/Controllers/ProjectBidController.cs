﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MvcCrudApp.Models;
using MvcCrudApp.Services;

namespace MvcCrudApp.Controllers
{
    [Route("projectbids")]
    public class ProjectBidController : Controller
    {
        private readonly IProjectBidService _bidService;
        private readonly IProjectService _projectService;
        private readonly IUserService _userService;

        public ProjectBidController(IProjectBidService bidService, IProjectService projectService, IUserService userService)
        {
            _bidService = bidService;
            _projectService = projectService;
            _userService = userService;
        }

        // GET: /projectbids
        [HttpGet("")]
        public IActionResult Index()
        {
            var bids = _bidService.GetAll();
            return View(bids);
        }

        // GET: /projectbids/create
        [HttpGet("create")]
        public IActionResult Create()
        {
            // Provide lists of projects and users for selection.
            ViewBag.Projects = _projectService.GetAll();
            ViewBag.Users = _userService.GetAll();
            return View();
        }

        // POST: /projectbids/create
        [HttpPost("create")]
        public IActionResult Create(ProjectBid bid)
        {
            if (ModelState.IsValid)
            {
                _bidService.Add(bid);
                return RedirectToAction("Index");
            }
            ViewBag.Projects = _projectService.GetAll();
            ViewBag.Users = _userService.GetAll();
            return View(bid);
        }

        // Additional actions (Edit, Delete) can be added similarly.
    }
}
