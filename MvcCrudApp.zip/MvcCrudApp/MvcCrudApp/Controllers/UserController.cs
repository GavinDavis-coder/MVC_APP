﻿using Microsoft.AspNetCore.Mvc;
using MvcCrudApp.Models;
using MvcCrudApp.Services;

namespace MvcCrudApp.Controllers
{
    [Route("users")]
    public class UserController : Controller
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        // GET: /users
        [HttpGet("")]
        public IActionResult Index()
        {
            var users = _userService.GetAll();
            return View(users);
        }

        // GET: /users/create
        [HttpGet("create")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /users/create
        [HttpPost("create")]
        public IActionResult Create(User user)
        {
            if (ModelState.IsValid)
            {
                _userService.Add(user);
                return RedirectToAction("Index");
            }
            return View(user);
        }

        // GET: /users/edit/{id}
        [HttpGet("edit/{id}")]
        public IActionResult Edit(int id)
        {
            var user = _userService.GetById(id);
            if (user == null)
                return NotFound();
            return View(user);
        }

        // POST: /users/edit/{id}
        [HttpPost("edit/{id}")]
        public IActionResult Edit(User user)
        {
            if (ModelState.IsValid)
            {
                _userService.Update(user);
                return RedirectToAction("Index");
            }
            return View(user);
        }

        // GET: /users/delete/{id}
        [HttpGet("delete/{id}")]
        public IActionResult Delete(int id)
        {
            var user = _userService.GetById(id);
            if (user == null)
                return NotFound();
            return View(user);
        }

        // POST: /users/delete/{id}
        [HttpPost("delete/{id}"), ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _userService.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
