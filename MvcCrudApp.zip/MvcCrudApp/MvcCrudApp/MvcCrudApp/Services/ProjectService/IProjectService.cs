﻿using System.Collections.Generic;
using MvcCrudApp.Models;

namespace MvcCrudApp.Services
{
    public interface IProjectService
    {
        List<Project> GetAll();
        Project GetById(int id);
        void Add(Project project);
        void Update(Project project);
        void Delete(int id);
    }
}
