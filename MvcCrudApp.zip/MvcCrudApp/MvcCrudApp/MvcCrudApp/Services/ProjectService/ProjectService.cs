﻿using System.Collections.Generic;
using System.Linq;
using MvcCrudApp.Models;

namespace MvcCrudApp.Services
{
    public class ProjectService : IProjectService
    {
        private static List<Project> _projects = new List<Project>();

        public List<Project> GetAll() => _projects;

        public Project GetById(int id) => _projects.FirstOrDefault(p => p.Id == id);

        public void Add(Project project)
        {
            project.Id = _projects.Any() ? _projects.Max(p => p.Id) + 1 : 1;
            _projects.Add(project);
        }

        public void Update(Project project)
        {
            var existing = GetById(project.Id);
            if (existing != null)
            {
                existing.Title = project.Title;
                existing.Description = project.Description;
                existing.Tags = project.Tags;
                existing.Deadline = project.Deadline;
                existing.Technology = project.Technology;
                existing.Status = project.Status;
                existing.Funding = project.Funding;
                existing.SubmitterId = project.SubmitterId;
            }
        }

        public void Delete(int id)
        {
            var project = GetById(id);
            if (project != null)
            {
                _projects.Remove(project);
            }
        }
    }
}
