﻿using System.Collections.Generic;
using System.Linq;
using MvcCrudApp.Models;

namespace MvcCrudApp.Services
{
    public class UserService : IUserService
    {
        // Static list to simulate a data store.
        private static List<User> _users = new List<User>();

        public List<User> GetAll() => _users;

        public User GetById(int id) => _users.FirstOrDefault(u => u.Id == id);

        public void Add(User user)
        {
            // Auto-increment Id logic.
            user.Id = _users.Any() ? _users.Max(u => u.Id) + 1 : 1;
            _users.Add(user);
        }

        public void Update(User user)
        {
            var existing = GetById(user.Id);
            if (existing != null)
            {
                existing.Name = user.Name;
                existing.ProfilePicture = user.ProfilePicture;
                existing.Bio = user.Bio;
                existing.Email = user.Email;
                existing.Phone = user.Phone;
            }
        }

        public void Delete(int id)
        {
            var user = GetById(id);
            if (user != null)
            {
                _users.Remove(user);
            }
        }
    }
}
