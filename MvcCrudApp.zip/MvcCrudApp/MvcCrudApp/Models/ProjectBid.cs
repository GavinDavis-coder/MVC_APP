﻿using System;
using System.ComponentModel.DataAnnotations;

namespace MvcCrudApp.Models
{
    public class ProjectBid
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "A Project is required.")]
        public int ProjectId { get; set; } // Foreign key

        // Optional: only if you want to specify a bidder; otherwise, you can make this required.
        public int? BidderId { get; set; } // Foreign key

        [Required(ErrorMessage = "Status is required.")]
        public string Status { get; set; }

        public string Note { get; set; }
        public string Proposal { get; set; }
        public string Timeline { get; set; }

        public DateTime SubmittedTime { get; set; }

        // Navigation properties (you can ignore these if not needed)
        public Project Project { get; set; }
        public User Bidder { get; set; }
    }
}
