﻿using System;
using System.ComponentModel.DataAnnotations;

namespace MvcCrudApp.Models
{
    public class Project
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Project title is required.")]
        public string Title { get; set; }

        public string Description { get; set; }

        // Tags for filtering.
        public string Tags { get; set; }

        [Required(ErrorMessage = "Deadline is required.")]
        public DateTime Deadline { get; set; }

        public string Technology { get; set; }

        // Pending, In Progress, Completed.
        public string Status { get; set; }

        public decimal Funding { get; set; }

        // Foreign key reference to User.
        public int SubmitterId { get; set; }
    }
}
