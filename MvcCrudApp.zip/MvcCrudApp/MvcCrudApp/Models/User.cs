﻿using System.ComponentModel.DataAnnotations;

namespace MvcCrudApp.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }

        // Picture upload: URL or file path.
        public string ProfilePicture { get; set; }

        public string Bio { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Format.")]
        public string Email { get; set; }

        public string Phone { get; set; }
    }
}
