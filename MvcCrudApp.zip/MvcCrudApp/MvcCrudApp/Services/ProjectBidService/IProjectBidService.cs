﻿using System.Collections.Generic;
using MvcCrudApp.Models;

namespace MvcCrudApp.Services
{
    public interface IProjectBidService
    {
        List<ProjectBid> GetAll();
        ProjectBid GetById(int id);
        void Add(ProjectBid bid);
        void Update(ProjectBid bid);
        void Delete(int id);
    }
}
