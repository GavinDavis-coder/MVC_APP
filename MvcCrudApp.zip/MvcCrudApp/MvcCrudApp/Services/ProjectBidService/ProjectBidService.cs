﻿using System;
using System.Collections.Generic;
using System.Linq;
using MvcCrudApp.Models;

namespace MvcCrudApp.Services
{
    public class ProjectBidService : IProjectBidService
    {
        // Static in-memory storage.
        private static List<ProjectBid> _bids = new List<ProjectBid>();

        public List<ProjectBid> GetAll() => _bids;

        public ProjectBid GetById(int id) => _bids.FirstOrDefault(b => b.Id == id);

        public void Add(ProjectBid bid)
        {
            // Auto-increment Id.
            bid.Id = _bids.Any() ? _bids.Max(b => b.Id) + 1 : 1;
            // Set the submitted time.
            bid.SubmittedTime = DateTime.Now;
            _bids.Add(bid);
        }

        public void Update(ProjectBid bid)
        {
            var existing = GetById(bid.Id);
            if (existing != null)
            {
                existing.ProjectId = bid.ProjectId;
                existing.BidderId = bid.BidderId;
                existing.Status = bid.Status;
                existing.Note = bid.Note;
                existing.Proposal = bid.Proposal;
                existing.Timeline = bid.Timeline;
                // You can choose whether to update the SubmittedTime.
            }
        }

        public void Delete(int id)
        {
            var bid = GetById(id);
            if (bid != null)
                _bids.Remove(bid);
        }
    }
}

