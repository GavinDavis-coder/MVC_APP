MvcCrudApp

// Overview
- ASP.NET CORE MVC CRUD Application.
- User and Project models for data.
- User and Project controllers for managing CRUD operations.
- CRUD operations for Users and Projects using in-memory lists. 
- Attribute-based routing. 
- Razor views styled with Bootstrap for CRUD operations.
- Dependency injection.
- Basic validation using DataAnnotations.

// Setup Instructions
1. Clone the repository.
2. Open the solution in Visual Studio.
3. Build the solution.
4. Run the project.

// Functionality
- User is routed to Home page by default.
- User can select User or Project list.
- From User/Project list user can create new users/projects.
- Users/Projects are stored in the tables.
- Users/Projects can be edited/updated/deleted.
- Project list contains User ID (name) from User list.


// Bonus Features
- Search and filtering in the project list.
- File upload for user profile pictures.